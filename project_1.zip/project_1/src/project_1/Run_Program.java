package project_1;

import java.util.Scanner;

public class Run_Program {
	
	public static void main(String[] args){
		if (args.length == 0) {
			System.out.println("no argumets where given");
			System.exit(0);
		}//this if is to check if the main has any arguments or not.
		Scanner scan = new Scanner(System.in); //Scanner is used to scan entries from the console.
		while (!scan.hasNext("exit")){ // the program runs until exit is typed in the console
			
			if(scan.hasNextInt()){ // check if the data entered is a integer 
				int number = scan.nextInt(); // the integer is stored in number
				Numbers n = new Numbers(number); // Instantiation of the Constructor Numbers with the int gives as parameter in the step before
				
				if (n.even()) { // print out the result depending if odd or even.
					System.out.println("The " + number + " is even");
				} 
				else {
					if (n.Odd()){
						System.out.println("The " + number + "is Odd");
					}
				}
				
			}
			else { // security check if the entered data is integer, if not error message appears 
				System.out.println("Warning!Last Entry " + scan.findInLine(".[^0-9]*") + " Is not an Integer");
				scan.next(); // scanner can be reused after warning message
			}
		}
		System.out.println("Program is shutting down . . .");
		scan.close();//close the scanner.
		System.exit(0);//exit program.
	}

}
